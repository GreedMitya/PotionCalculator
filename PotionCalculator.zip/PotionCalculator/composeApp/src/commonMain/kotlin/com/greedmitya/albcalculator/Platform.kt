package com.greedmitya.albcalculator

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform